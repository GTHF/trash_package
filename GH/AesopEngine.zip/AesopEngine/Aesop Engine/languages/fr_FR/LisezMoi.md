# TraductionFRCheatEngine
Traduction française de Cheat Engine

Voici les étapes pour mettre Cheat Engine en français :

- Décompresser le dossier 'languages'
- Placer le dossier décompressé dans le répertoire d'installation de Cheat Engine : (par défaut : C:\Program Files\Cheat Engine 7.0)
- Remplacez les fichiers lorsque cela vous est demandé
- Lancez Cheat Engine et amusez-vous !

La traduction des tutoriels a été effectuée par KéKéCoRe! puis refaite/corrigée par Monologix.
La traduction de l'interface a été effectuée par Monologix.

Pour m'aider à proposer une traduction encore meilleure, vous pouvez me contacter par mail (monologixfr@gmail.com) ou par discord https://discord.gg/XEf2zUz.

By KéKéCoRe! / Monologix

Version 0.1  (19/04/2020) :
- Traduction de l'interface de base affichée directement à l'utilisateur
- Correction de la traduction des tutoriels effectués par KéKéCoRe!

Version 0.2 (23/04/2020) :
- Traduction de nouveaux éléments d'interface
- Correction de plusieurs erreurs de traduction

Version 0.3 (24/04/2020) :
- Traduction de plusieurs centaines éléments d'interface
- Correction d'un grand nombre d'erreurs de traduction

Version 0.4 (30/04/2020) :
- Traduction d'éléments d'interface
