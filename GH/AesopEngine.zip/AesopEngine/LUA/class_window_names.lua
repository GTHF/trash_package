local function isEmpty(s)
  return s == nil or s == ''
end

for i = 0, getFormCount() - 1 do
    local form = getForm(i)
    for j = 0, form.getComponentCount() - 1 do
        local component = form.getComponent(j)
        if not isEmpty(component.Caption) then
          component.Caption = '.'..component.Caption
        end
        if not isEmpty(component.Title) then
           component.Title = '.'..component.Title
        end
        if not isEmpty(component.ClassName) then
           component.ClassName = '.'..component.ClassName
        end
    end
end